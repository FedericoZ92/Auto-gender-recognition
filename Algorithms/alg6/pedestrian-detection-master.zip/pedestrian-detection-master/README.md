# pedestrian-detection

Towards real-time Pedestrain detection base on pyramid histogram of oriented gradient (PHOG) and support vector machine (SVM) with the histogram intersection kernel (HIK).

Reference

[1] DALAL N, TRIGGS B. Histograms of Oriented Gradients for Human Detection[C]//IEEE, 1: 886–893.

[2] MAJI S, BERG A C, MALIK J. Classification using intersection kernel support vector machines is efficient[C]//IEEE: 1–8.

