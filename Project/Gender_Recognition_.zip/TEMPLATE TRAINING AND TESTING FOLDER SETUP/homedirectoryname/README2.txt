Place training images of class n in: n_train
Place training images of class n in: n_test

When Confusion matrix is computed xtoy folders will be delivered x-labelled image classified as image of label y