# HOG-Pedestrian-Detector
MATLAB implementation of a basic HOG + SVM pedestrian detector. 
Computer Science Master thesis: https://upcommons.upc.edu/bitstream/handle/2099.1/21343/95066.pdf?sequence=1&isAllowed=y
